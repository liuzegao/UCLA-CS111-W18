#!/usr/local/cs/bin/python3

# NAME: Quentin Truong
# EMAIL: quentintruong@gmail.com
# ID: 404782322


def main():
    print("2")

if __name__ == "__main__":
    main()